package com.example.fordogfans.ui.base

interface BaseView {
}