package com.example.fordogfans.model

data class Breed(val name:String, val subBreeds: List<String>)
